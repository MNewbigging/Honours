﻿using UnityEngine;
using System.Collections;
using System.Threading;
using System.IO.Ports;
using System;

// Spawns 2 threads, one to incoming and outgoing com ports

public class ControllerListenerV2 : MonoBehaviour {

    // COM port properties  
    private string incoming = "COM6";
    private string outgoing = "COM5";
    private int baudRate = 9600;
    private int readTimeOut = 1000;
    private int bufferSize = 1;
    private bool programActive = true;
    private bool paired = false;
    SerialPort inPort, outPort;
    Thread inThread, outThread;
    // Send input events to Input manager
    private InputMgr inputMgr;

    // Keep this alive throughout
    private void Awake()
    {
        DontDestroyOnLoad(this);
    }

    // Initialise ports, set threads running
    private void Start() {

        // Link up with InputMgr
        inputMgr = GameObject.FindGameObjectWithTag("InputMgr").GetComponent<InputMgr>();

        // Incoming com port
        try
        {
            inPort = new SerialPort(incoming, baudRate, Parity.None, 8, StopBits.One);
            inPort.ReadTimeout = readTimeOut;
            inPort.Open();
            inThread = new Thread(new ThreadStart(() => IncomingThread()));
            inThread.Start();
        } catch (Exception e) { Debug.Log("IN ERROR: " + e.Message); }       
        // Outgoing com port
        try
        {

            //outPort = new SerialPort(outgoing, baudRate, Parity.None, 8, StopBits.One);
            //outPort.ReadTimeout = readTimeOut;
            //outPort.Open();
            //outThread = new Thread(new ThreadStart(() => OutgoingThread()));
            //outThread.Start();
        } catch (Exception e) { Debug.Log("OUT ERROR: " + e.Message); }

    }

    // Stop threads on program exit
    private void OnDisable()
    {
        programActive = false;
        if (inPort.IsOpen)
            inPort.Close();
        //if (outPort.IsOpen)
        //    outPort.Close();
    }


    // Incoming thread - listen for input events from controller
    private void IncomingThread()
    {
        Debug.Log("In thread started.");
        // Read in data to this buffer
        Byte[] buffer = new Byte[bufferSize];
        // Details number of bytes read on inPort
        int bytesRead = 0;

        while (programActive)
        {
            try
            { 
                // Try reading inPort
                bytesRead = inPort.Read(buffer, 0, bufferSize);
                // If something was read into buffer
                if (bytesRead > 0)
                {
                    // Parse byte to int 
                    int inputEvent = buffer[0] - 48; // avoids actually converting/parsing
                    // Send to input manager to handle
                    inputMgr.ReceiveInputEvent(inputEvent);
                }
                
                
            } catch (Exception e) {
                //Debug.Log("I: "+ e.Message);
            }       
        }

        // Close the com port
        if (inPort.IsOpen)
            inPort.Close();

        Debug.Log("In thread dead");
    }

    // Outgoing thread - send (un)pairing messages
    private void OutgoingThread()
    {
        Debug.Log("out thread started");
        byte[] pair = new byte[1];
        pair[0] = 80;
        byte[] unpair = new byte[1];
        unpair[0] = 85;
        while (programActive)
        {
            try
            {
                // Attempt to pair
                if (!paired)
                {
                    // Send pair request until paired
                    //outPort.Write(pair, 0, 1);
                    outPort.WriteLine("P");
                    outPort.BaseStream.Flush();
                }

            } catch (Exception e) { Debug.Log("O: " + e.Message);  }
        }

        // Unpair
        try
        {
            // Send unpair request
            //outPort.Write(unpair, 0, 1);
            outPort.WriteLine("U");
            outPort.BaseStream.Flush();

        } catch (Exception e) { Debug.Log("Unpair: " + e.Message); }

        outPort.Close();
        Debug.Log("Out thread dead");
    }





}
