﻿using UnityEngine;
using System.Collections;

public class PlayerInput : MonoBehaviour {

    // Ref to pause screen 
    private GameObject pauseMenu;
    private bool paused = false;
    // Movement variables
    private float speed = 0.0f;
    private const float topSpeed = 5.0f;
    private float turnSpeed = 100.0f;
    private float rotation;
   

    private float countdown = -1.0f;
    private const float countdownLimit = 5.0f; // 5 seconds

    // set pause menu obj ref, make inactive at start
    private void Start()
    {
        pauseMenu = GameObject.FindGameObjectWithTag("PauseMenu");
        pauseMenu.SetActive(false);

    }

    // Move player, update countdown timer
    private void FixedUpdate()
    {
        // Reduce countdown clock
        countdown -= Time.deltaTime;

        // Move player
        MovePlayer();
    }

    // Player is always rotated/moved forward - rot and speed vars can be 0 at standstill
    private void MovePlayer()
    {
        // Rotate player
        float rot = rotation * turnSpeed * Time.deltaTime;
        transform.Rotate(0, rot, 0);

        // Determine player speed - 0 if countdown ended, 5 otherwise
        speed = (countdown < 0 ? 0.0f : topSpeed);

        // Move player forward based on speed
        transform.position += transform.forward * speed * Time.deltaTime;

    }


    // Called when receiving input events from controller, sets player vars accordingly
    public void HandlePlayerInput(int inputEvent)
    {
        Debug.Log("Player handling event: " + inputEvent);
        // Listen for select button press
        switch (inputEvent)
        {
            case 0: // Joystick idle
                rotation = inputEvent;
                break;
            case 1: // Joystick right
                rotation = inputEvent;
                break;
            case 2: // Joystick left
                rotation = -1;
                break;
            case 3: // Joystick down
                
                break;
            case 4: // Joystick up
               
                break;
            case 5: // Magnet detected
                // user is pedalling - reset countdown
                countdown = countdownLimit;
                break;
            case 6: // Button 1 pressed
                if (paused)
                {
                    // Quit game
                    UnityEditor.EditorApplication.isPlaying = false;
                    // Application.Quit();
                }
                break;
            case 7: // Button 2 pressed
                // Pause game
                if (Time.timeScale > 0)
                {
                    Time.timeScale = 0;
                    // Show pause menu
                    pauseMenu.SetActive(true);
                    paused = true;
                }
                // Unpause game 
                else
                {
                    // Hide pause menu
                    pauseMenu.SetActive(false);
                    Time.timeScale = 1;
                    paused = false;
                }
                break;
            default:
                Debug.Log("Default event: " + inputEvent);
                break;
        }

    }
}
