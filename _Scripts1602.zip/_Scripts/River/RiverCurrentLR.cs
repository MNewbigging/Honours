﻿using UnityEngine;
using System.Collections;

public class RiverCurrentLR : MonoBehaviour {


    // Current strength
    private float currentSpeed = 1.2f;
    // Setter
    public void ChangeCurrentDirection(float newCurrentSpeed) { currentSpeed = newCurrentSpeed; }


    // Current - move everything on this river piece
    private void OnTriggerStay(Collider other)
    {
        // Move it downstream - LR moves on x axis
        Vector3 downstream = new Vector3((currentSpeed * Time.deltaTime), 0, 0);
        other.transform.position += downstream;
    }
}
