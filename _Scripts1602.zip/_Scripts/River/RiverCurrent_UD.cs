﻿using UnityEngine;
using System.Collections;

public class RiverCurrent_UD : MonoBehaviour {

    // Current speed
    private float currentSpeed = 5.2f;
    // Change current direction 
    public void ChangeCurrentDirection(float newCurrentSpeed) { currentSpeed = newCurrentSpeed; }

   
    // Current - move everything on this river piece
    private void OnTriggerStay(Collider other)
    {
        // Move it downstream - UD moves on z axis
        Vector3 downstream = new Vector3(0, 0, (currentSpeed * Time.deltaTime));
        other.transform.position += downstream;
    }
}
