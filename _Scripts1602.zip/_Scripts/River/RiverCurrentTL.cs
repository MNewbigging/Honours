﻿using UnityEngine;
using System.Collections;

public class RiverCurrentTL : MonoBehaviour {

    // River current strength
    private float currentSpeed = 5.2f;
    // Setter
    public void ChangeCurrentDirection(float newCurrentSpeed) { currentSpeed = newCurrentSpeed; }

    private void OnTriggerStay(Collider other)
    {
        // Move it downstream
        Vector3 downstream = new Vector3((currentSpeed * Time.deltaTime), 0, (currentSpeed * Time.deltaTime));
        other.transform.position += downstream;
    }
}
