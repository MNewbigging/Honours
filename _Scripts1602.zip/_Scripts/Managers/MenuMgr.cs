﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

// Loads game, quits application. Handles input taken from InputMgr
public class MenuMgr : MonoBehaviour {

    // Tracks currently selected item
    // 0 - Start
    // 1 - Quit
    private int curSelected = 0;


    // Load game
    public void LoadGame()
    {
        SceneManager.LoadScene(1);
    }

    // Exit application
    public void QuitGame()
    {
        Application.Quit();
    }

    // Handle input for main menu
    public void HandleMainMenuInput(int inputEvent)
    {
        Debug.Log("Main menu handling event: " + inputEvent);
        // Listen for select button press
        switch (inputEvent)
        {
            case -1: // Joystick left
                // Highlight item to left (if there is one)
                if (curSelected > 0)
                {
                    curSelected--;
                }
                break;
            case 0: // Joystick reset
                // do nothing
                break;
            case 1: // Joystick right
                // Highlight item to right (if there is one)
                if (curSelected < 1)
                {
                    curSelected++;
                }
                break;
            case 2: // Magnet detected

                break;

            case 3: // Button 1 pressed
                // Run click event of curSelected button
                if (curSelected == 0)
                {
                    // Load game
                    SceneManager.LoadScene(1);
                }
                else if (curSelected == 1)
                {
                    // Quit game
                    UnityEditor.EditorApplication.isPlaying = false;
                }
                break;
            case 4: // Button 2 pressed

                break;
            default:
                Debug.Log("Default event: " + inputEvent);
                break;
        }
    }
    

}
