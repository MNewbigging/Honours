﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.IO;

// Handles all timing data for the game, writes to file

public class StatMgr : MonoBehaviour {

    // Total game length timer
    private float totalSessionLength = 0.0f;
    private Text gameTimer;


    // Setup text ref objs
    private void Start()
    {
        gameTimer = GameObject.FindGameObjectWithTag("GameTimer").GetComponent<Text>();
    }
    
    // Keep clocks ticking
    private void FixedUpdate()
    {
        // Update total game length timer
        totalSessionLength += Time.deltaTime;
        // Find minutes
        string mins = Mathf.Floor(totalSessionLength / 60).ToString("00");
        // Find seconds
        string secs = Mathf.Floor(totalSessionLength % 60).ToString("00");
        // Set clock accordingly
        gameTimer.text = "Game time: " + mins + ":" + secs;
    }



    // On game end, write data to file
    private void OnDisable()
    {
        // The location of file 
        string path = "Assets/Saves/saves.txt";
        // Write data to file
        StreamWriter writer = new StreamWriter(path, true); // true appends
        writer.WriteLine(gameTimer.text);
        writer.Close();
   
    }








}
